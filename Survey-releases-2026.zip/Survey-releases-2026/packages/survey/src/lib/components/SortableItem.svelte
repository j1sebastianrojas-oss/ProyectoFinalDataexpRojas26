<script lang="ts">
	import type { Snippet } from 'svelte'

	import { createSortable } from '@dnd-kit/svelte/sortable'

	let {
		id,
		index,
		children,
	}: {
		id: string
		index: number
		children: Snippet<[{ isDragging: boolean }]>
	} = $props()

	const sortable = createSortable({
		get id() {
			return id
		},
		get index() {
			return index
		},
	})
</script>

<li {@attach sortable.attach} class="sortable-item" class:dragging={sortable.isDragging}>
	{@render children({ isDragging: sortable.isDragging })}
</li>

<style>
	.sortable-item {
		background: var(--bg-page);
		list-style: none;
		touch-action: none;
	}
</style>
